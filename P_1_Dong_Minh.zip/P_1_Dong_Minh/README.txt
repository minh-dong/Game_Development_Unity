Name: Minh Dong
Title: Programming Assignment One
Description: Computing GCD and LCD
Due Date: 12:00 PM February 7

------------------------------------------------------

C# Code Project (The entire P1_Base Folder)
Report (PDF Document)
HTML Documentation (Inside P1_Base\Documentation Folder)
Doxygen Config (Inside P1_Base\Documentation Folder)